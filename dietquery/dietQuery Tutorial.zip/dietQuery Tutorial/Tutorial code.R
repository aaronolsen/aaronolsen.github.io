################################## dietQuery Tutorial ####################################
#
# Author: Aaron Olsen (aolsen@uchicago.edu)
# Date: September 17, 2014
#
# This is a tutorial file for dietQuery, an R package currently in development. dietQuery 
# allows users to query animal diet data sets, such as studies of gut or fecal contents. 
# All the code files needed to run the examples in the tutorial are included in the 
# Tutorial folder. Eventually, dietQuery will be available as an R package downloadable 
# through CRAN (http://cran.r-project.org/).
#
# Examples:
# 1. Reading in diet sets
# 2. Using queryIsMember()
# 3. Querying the data sets
#
# To perform the examples in this tutorial, place the unzipped 'dietQuery Tutorial' 
# somewhere on your computer and change the working directory in R to the 'dietQuery 
# Tutorial' folder. This can be done by going to 'Misc' > 'Change Working Directory...' 
# or using the setwd() function, replacing the file path with the path to the tutorial 
# folder on your computer.

setwd('~/Downloads/dietQuery Tutorial')

# Then copy and paste the lines of code below into the R console.

source_apply <- sapply(paste0("R/", list.files("R")), source, .GlobalEnv)
if(!exists("eval.ref")) eval.ref <- loadEvalRef("eval_ref")

# The first command loads all of the R functions currently included in the dietQuery 
# package and needed to run the examples in this tutorial. The second command reads in the 
# reference files. The reference files include the nearly complete NCBI taxonomy 
# (everything except bacteria and viruses), over 600,000 entries. This reference folder 
# will be used when performing taxonomy-based searches.
#
# NCBI Taxonomy Browser: http://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi

############################ Example 1. Reading in diet sets #############################

# The diet data sets consist of a main file that lists each study (observation) plus 
# associated metadata (season, year and location of collection, study citation, number of
# individuals, etc.) and data matrix files that list each dietary component (part and 
# taxonomic name) and their proportion of the diet (by volume, weight, frequency, etc.).
# Example quantitative data sets from four different diet studies are included in the 
# 'diet sets' folder (Salyer & Lagler 1940; Gammonley & Heitmeyer 1990; 
# Budeau et al. 1991; Owen 1973).
#
# Read in the tutorial data sets using readDietSets().

sets <- readDietSets(file="diet_sets", eval.ref)

# The reference list (eval.ref) is input into this function since it includes a file that 
# replaces non-standard names in the diet data with standard names (e.g. 'sea lettuce' is 
# changed to 'ulva').
#
# To check whether all of the item names in the data sets are in the reference files, 
# set the input parameter check.names to TRUE

sets <- readDietSets(file="diet_sets", eval.ref, check.names=TRUE)

# This will print a warning if any of the items are not found in the reference files. To 
# print the sets or a particular set, simply use the print() function.

print(sets[[4]])

########################### Example 2. Using queryIsMember() #############################

# The queryIsMember() function is used to query whether one object (the entry) is a 
# member of a second object (the group) within a specified classification scheme. This 
# classification scheme can be specified by the user, such as the 'names.txt' file in the 
# dietQuery Tutorial folder ('eval_ref/diet_part/diet_parts/names.txt'). This file groups 
# over 60 different diet parts into hierarchical categories so that they can be queried by
# queryIsMember(). For example, to ask whether a 'flower' is a 'plant part', one would 
# type the following, which will print TRUE.

queryIsMember("petal", "plant part", "diet_part", eval.ref)

# This works at multiple levels. The following queries will also return TRUE.

queryIsMember("petal", "flower", "diet_part", eval.ref)
queryIsMember("flower", "plant reproductive organ", "diet_part", eval.ref)
queryIsMember("petal", "plant reproductive organ", "diet_part", eval.ref)

# But a 'leaf' is not a plant reproductive organ, and the following will return FALSE:

queryIsMember("leaf", "plant reproductive organ", "diet_part", eval.ref)

# If you send a query for a structure not included in the reference file, the function 
# will return NA and a warning.

queryIsMember("apples", "plant reproductive organ", "diet_part", eval.ref)

# You can change the 'names.txt' file to reflect the hierarchical relationships that are
# most suitable for your needs. If you change any of these folders, you'll need to call 
# loadEvalRef() to update the existing eval.ref. The 'diet_part' folder only includes 
# reference for parts of plants and animals, not taxonomic names (e.g. apple, frog, 
# Xenopus, etc.). Taxonomic classifications are included in the 'taxonomy' folder.

# The 'taxonomy' folder contains the majority of content from the NCBI taxonomy
# (http://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi). Names that contain numbers 
# and those in a few other categories are excluded (these include most of the bacterial 
# and viral cultures which are not generally relevant for the current functionalities of
# dietQuery. After excluding entries from these categories, the 'taxonomy' folder still 
# provides a reference to approximately 649,000 taxonomic entities at all hierarchical 
# levels.

# queryIsMember() can be used with the NCBI taxonomy in the same manner as described 
# previously. For example, the following query, whether 'homo sapiens' is a member of 
# 'primates', returns TRUE.

queryIsMember("homo sapiens", "primates", "taxonomy", eval.ref)

# However, the following query, whether 'mus musculus' (house mouse) is a member of 
# 'primates', returns FALSE.

queryIsMember("mus musculus", "primates", "taxonomy", eval.ref)

# The first and second parameters to queryIsMember can be at any taxonomic level as long
# as they are valid names in the NCBI taxonomy (they should also be lowercase for 
# proper matching). The following queries all return TRUE

queryIsMember("primates", "amniota", "taxonomy", eval.ref)
queryIsMember("teleostei", "metazoa", "taxonomy", eval.ref)
queryIsMember("hymenoptera", "arthropoda", "taxonomy", eval.ref)

# while the following queries all return FALSE

queryIsMember("amniota", "primates", "taxonomy", eval.ref)
queryIsMember("metazoa", "teleostei", "taxonomy", eval.ref)
queryIsMember("arthropoda", "hymenoptera", "taxonomy", eval.ref)

# since 'amniota' are not members of the group 'primates' (it's the other way around) and
# so on.

############################ Example 3. Querying the data sets ###########################

# The search criteria include the fields to be searched, the value to be compared against 
# the value in the set and the type of comparison to be made (=, !=, >, <, >=, <=). For 
# instance, to test for whether each diet data set include insects, use the following 
# criteria:

criteria <- 'item = insects'

# To apply this search criteria to the loaded sets, use querySets(). This can about a 
# minute to run. The function will return a vector of TRUE, FALSE or NA for each loaded 
# diet set.

query_sets <- querySets(sets, criteria, "evaluate_set_dietquery", eval.ref)

# To match up the results from querySets() with the input sets, retrieve only the latin
# name and source from the sets.

read_sets <- readSets(sets, entries=c('latin name', 'source'))

# Then print the results of QuerySets() side by side with the latin name and source.

cbind(read_sets[['latin name']], read_sets[['source']], query_sets)

# The only data set containing insects is the Gammonley and Heitmeyer (1990) data set for 
# the Bufflehead (Bucephala albeola).
#
# It is also possible to search for sets that only include a particular item. To do this, 
# include 'only' after 'item'.

query_sets <- querySets(sets, 'item only = animals', "evaluate_set_dietquery", eval.ref)

# Only the Salyer and Lagler (1940) data set for the Hooded Merganser (Lophodytes 
# cucullatus) contains only animals; the data set consists entirely of fish and 
# crustaceans.

cbind(read_sets[['latin name']], read_sets[['source']], query_sets)

# It is possible to construct much more elaborate search criteria, including nested 
# conditions. For example, the following criteria will test whether the data set includes 
# either insects or seeds and whether the number of individuals in the study is greater 
# than 10.

criteria <- "(item = insects OR part = seeds) AND n > 10"
query_sets <- querySets(sets, criteria, "evaluate_set_dietquery", eval.ref)
cbind(read_sets[['latin name']], read_sets[['source']], query_sets)

# Three of the four data sets satisfy these criteria, all except Lophodytes cucullatus.
