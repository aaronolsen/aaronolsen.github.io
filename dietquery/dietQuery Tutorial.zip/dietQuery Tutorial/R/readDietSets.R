readDietSets <- function(file, eval.ref, check.names=FALSE){

	# IF FILE IS DIRECTORY, READ FILES AS VECTOR
	if(length(file) == 1) if(!grepl('.txt$', file)) file <- paste0(file, '/', list.files(file))

	# EXCLUDE FILES NON TXT FILES AND FOLDERS
	file <- file[grep('.txt$', file)]

	# READ IN STANDARD REFERENCE/REPLACE FILES
	replace_taxonomy <- matrix(NA, nrow=0, ncol=2)
	for(ref_name in names(eval.ref[['taxonomy']])){
		
		# MAKE SURE REPLACE LIST EXISTS
		if(is.null(eval.ref[['taxonomy']][[ref_name]][['replace']])) next
		
		# ADD ROWS TO MATRIX
		replace_taxonomy <- rbind(replace_taxonomy, as.matrix(eval.ref[['taxonomy']][[ref_name]][['replace']]))
	}

	# FORMAT DIET PARTS FOR SEARCH
	diet_parts_ref <- gsub('\t', '', eval.ref[['diet_part']][['diet_parts']][['names']], fixed=TRUE)
	diet_parts_ref <- gsub('^', '', diet_parts_ref, fixed=TRUE)
	diet_parts_ref <- gsub('$', '', diet_parts_ref, fixed=TRUE)

	# SORT BY NUMBER OF CHARACTERS IN SEARCH STRING
	diet_parts_ref <- unique(diet_parts_ref[order(nchar(diet_parts_ref), decreasing=TRUE)])

	sets <- list()
	set_n <- 1

	for(i in 1:length(file)){
		
		# READ IN FILE
		read_lines <- readLines(file[i])
		
		# GET PATH TO MATRIX FILES
		file_dir_split <- unlist(strsplit(file[i], '/'))
		file_dir <- paste0(paste(file_dir_split[1:(length(file_dir_split)-1)], collapse='/'), '/')
		
		# COLLAPSE INTO SINGLE STRING
		read_lines <- paste(read_lines, collapse="\n")
		
		# SPLIT INTO SETS AT LATIN NAME
		sets_split <- paste0('latin name', unlist(strsplit(read_lines, 'latin name'))[-1])

		for(j in 1:length(sets_split)){

			# SPLIT AT TABS
			set_split <- unlist(strsplit(sets_split[j], '\t|\n'))
			
			# REMOVE EMPTY ELEMENTS
			set_split <- set_split[!grepl("^(\n| )*$", set_split)]
			
			# CHECK THAT EACH ROW HAD A FIELD NAME
			if(length(set_split) %% 2 != 0){
				print(set_split)
				stop(paste0("Field name missing from set ", j, " in ", file[i], ""))
			}

			# SAVE AS MATRIX WITH FIELD NAMES IN FIRST COLUMN AND VALUES IN SECOND
			set_matrix <- matrix(set_split, ncol=2, byrow=TRUE)
			
			# SET FIELD NAMES, TRIM
			field_names <- set_matrix[, 1] <- gsub(" ", " ", gsub(" *$|^ *", "", set_matrix[, 1]))
			
			# GET UNIQUE FIELD NAMES
			field_names_unique <- unique(field_names)
			
			# FIND FIELD NAMES TO SET INTO SUB-LIST
			reg_expr <- regexpr('[A-Za-z]+_', field_names_unique)
			assub <- reg_expr > 0
			field_names_lead <- substr(field_names_unique, reg_expr, reg_expr+attr(reg_expr, "match.length")-2)

			# MAKE NEXT SET
			sets[[set_n]] <- list()
			class(sets[[set_n]]) <- 'query_set'
			
			# SAVE VALUES TO SET LIST
			for(field_name in field_names_unique){
				
				if(field_name == 'source text' || field_name == 'note') next
				
				if(field_name == 'source'){
					value <- strsplit(paste(set_matrix[set_matrix[, 1] == field_name, 2], collapse=" ; "), "( )*;( )*")
				}else{
					value <- strsplit(paste(set_matrix[set_matrix[, 1] == field_name, 2], collapse=" ; "), "( )*(&|;)( )*")
				}

				# TRIM WHITESPACES FROM VALUES
				value <- gsub(" *$|^ *", "", unlist(value))
				
				# SET NA VALUES TO CLEAN NA
				value[value == "NA"] <- NA

				if(length(value) == 1 && !assub[which(field_name == field_names_unique)]){
				
					# TEXT FILE PROVIDED INSTEAD OF VALUES
					if(grepl('.txt$', value)){

						# READ DATA MATRIX
						read_table <- as.matrix(read.table(paste0(file_dir, value), sep='\t', header=TRUE, check.names=FALSE))

						# ADD EACH COLUMN OF DATA MATRIX TO SUBLIST IN SET
						for(k in 1:ncol(read_table)) sets[[set_n]][[field_name]][[colnames(read_table)[k]]] <- read_table[, k]
						
					}else{
						sets[[set_n]][[field_name]] <- value
					}
				}else if(length(value) > 1 && !assub[which(field_name == field_names_unique)]){
					sets[[set_n]][[field_name]][[field_name]] <- value
				}else{
					sublist_name <- field_names_lead[which(field_name == field_names_unique)]
					sets[[set_n]][[sublist_name]][[gsub(paste0(sublist_name, '_'), '', field_name)]] <- value
				}

			}
			set_n <- set_n + 1
		}
	}

	# REPLACE DIET ITEMS WITH STANDARD NAMES (MATCHING THOSE USED IN TAXONOMY)
	for(i in 1:length(sets)){
		for(j in 1:length(sets[[i]][['diet']][['item']])){

			# SKIP NA
			if(is.na(sets[[i]][['diet']][['item']][j])) next
			
			# SEARCH THROUGH STANDARD REPLACE PATTERNS
			match <- 0
			for(k in 1:nrow(replace_taxonomy)){

				# TEST SEARCH PATTERN AGAINST CURRENT ITEM NAME
				grepl_r <- grepl(replace_taxonomy[k, 2], sets[[i]][['diet']][['item']][j], ignore.case=TRUE)

				# IF MATCHING, SAVE CORRESPONDING ROW
				if(grepl_r == TRUE){
					match <- k
					break
				}
			}

			# IF MATCH FOUND, REPLACE WITH STANDARD NAME
			if(match != 0) sets[[i]][['diet']][['item']][j] <- replace_taxonomy[k, 1]
		}
	}

	class(sets) <- 'query_set'

	# IF CHECK.NAMES IS FALSE, DO NOT CHECK DIET ITEMS AGAINST TAXONOMIES
	if(!check.names) return(sets)

	match_list <- list()

	for(i in 1:length(sets)){
		for(j in 1:length(sets[[i]][['diet']][['item']])){

			# DEFINE SEARCH TEXT
			search_text <- tolower(sets[[i]][['diet']][['item']][j])
			
			# CHECK IF SEARCH HAS ALREADY BEEN DONE
			if(!is.null(match_list[[search_text]])) next

			# SKIP IF NA
			if(is.na(search_text)) next
			
			# SET INITIAL FOUND
			found <- FALSE
			for(ref_name in names(eval.ref[['taxonomy']])){
				
				# CHECK THAT NAMES FIELD IS PRESENT IN REFERENCE
				if(!'names' %in% names(eval.ref[['taxonomy']][[ref_name]])) next

				# TEST WHETHER NAMES ARE PRESENT IN EVAL.REF
				if(is.null(dim(eval.ref[['taxonomy']][[ref_name]][['names']]))){
				
					match_res <- NA
					search_names <- gsub('\t|\n', '', eval.ref[['taxonomy']][[ref_name]][['names']])
					for(k in 1:length(search_names)){
						if(grepl(search_names[k], search_text)){match_res <- 1;break}
					}

				}else{
					match_res <- match(search_text, eval.ref[['taxonomy']][[ref_name]][['names']][, 1])
				}
				
				# MAKE FOUND TRUE IF MATCH FOUND
				if(!is.na(match_res)){
					found <- TRUE
					match_list[[search_text]] <- TRUE
				}
			}

			if(found == FALSE){
				message(paste0("Warning: '", sets[[i]][['diet']][['item']][j], "' was not found in the eval.ref names list(s)"))
				match_list[[search_text]] <- FALSE
			}
		}
	}

	sets
}