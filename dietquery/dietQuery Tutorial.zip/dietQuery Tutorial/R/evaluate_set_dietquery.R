evaluate_set_dietquery <- function(set, criteria, col.index, eval.ref){

	# SET FIELDS AND VALUES TO LOWERCASE
	criteria$field <- tolower(criteria$field)
	criteria$value <- tolower(criteria$value)
	set[[criteria$field]][col.index] <- tolower(set[[criteria$field]][col.index])

	if(criteria$field == 'item'){

		# IF ENTRY IS NA
		if(is.na(set[['item']][col.index])){

			# IF PART IS ALSO NA, RETURN NA
			if(is.na(set[['part']][col.index])) return(NA)
		
			# CHECK IF PART INFORMS CLASSIFICATION
			is_plant_part <- queryIsMember(set[['part']][col.index], 'plant parts', 'diet_part', eval.ref)
			is_animal_part <- queryIsMember(set[['part']][col.index], 'animal parts', 'diet_part', eval.ref)
			is_value_plant <- grepl('plant(s)?', criteria$value)
			is_value_animal <- grepl('animal(s)?', criteria$value)

			if(is_animal_part){
				if(is_value_plant && criteria$compare == "=") return(FALSE)
				if(is_value_plant && criteria$compare == "!=") return(TRUE)
				if(is_value_animal && criteria$compare == "=") return(TRUE)
				if(is_value_animal && criteria$compare == "!=") return(FALSE)
			}

			if(is_plant_part){
				if(is_value_animal && criteria$compare == "=") return(FALSE)
				if(is_value_animal && criteria$compare == "!=") return(TRUE)
				if(is_value_plant && criteria$compare == "=") return(TRUE)
				if(is_value_plant && criteria$compare == "!=") return(FALSE)
			}

			return(NA)
		}

		#cat("\tIs '", set[['item']][col.index], "' a member of '", criteria$value, "'?\n", sep="")

		# QUERY WHETHER ENTRY IS MEMBER OF TAXON
		is_member <- queryIsMember(set[['item']][col.index], criteria$value, 'taxonomy', eval.ref)

		if(criteria$compare == "=") return(is_member)
		if(criteria$compare == "!=") return(!is_member)

		stop(paste0(criteria$compare, " is not a valid comparison symbol for 'diet item'"))
	}

	# IF VALUE IS NA, RETURN NA
	if(is.na(set[[criteria$field]][col.index])){
		if(criteria$value == "NA"){
			if(criteria$compare == "=") return(TRUE)
			if(criteria$compare == "!=") return(FALSE)
		}
		return(NA)
	}

	if(criteria$field == 'part'){

		# QUERY WHETHER ENTRY IS MEMBER OF PART
		is_member <- queryIsMember(set[['part']][col.index], criteria$value, 'diet_part', eval.ref)

		if(criteria$compare == "=") return(is_member)
		if(criteria$compare == "!=") return(!is_member)

		stop(paste0(criteria$compare, " is not a valid comparison symbol for 'diet part'"))
	}

	if(criteria$field == 'frequency'){

		# FIND NUMBER IN VALUE
		reg_expr <- regexpr('[0-9.]+', criteria$value)
		
		# GET JUST NUMBER
		criteria$value <- substr(criteria$value, reg_expr, reg_expr+attr(reg_expr, "match.length")-1)
		
		# IF NO NUMBER PRESENT, RETURN NA
		if(length(criteria$value) == 0) return(NA)

		# CONVERT TO NUMERIC
		criteria$value <- as.numeric(criteria$value)

		# FIND UNITS AND MAKE UNIT-BASED COMPARISON	
	}

	if(criteria$compare == "=")
		if(set[[criteria$field]][col.index] == criteria$value){return(TRUE)}else{return(FALSE)}

	if(criteria$compare == "!=")
		if(set[[criteria$field]][col.index] == criteria$value){return(FALSE)}else{return(TRUE)}

	if(criteria$compare == ">")
		if(set[[criteria$field]][col.index] > criteria$value){return(TRUE)}else{return(FALSE)}

	if(criteria$compare == "<")
		if(set[[criteria$field]][col.index] < criteria$value){return(TRUE)}else{return(FALSE)}

	if(criteria$compare == ">=")
		if(set[[criteria$field]][col.index] >= criteria$value){return(TRUE)}else{return(FALSE)}

	if(criteria$compare == "<=")
		if(set[[criteria$field]][col.index] <= criteria$value){return(TRUE)}else{return(FALSE)}

	return(NA)
}