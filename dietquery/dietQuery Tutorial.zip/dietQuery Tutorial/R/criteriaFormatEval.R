criteriaFormatEval <- function(criteria){

	for(i in 1:length(criteria)){
		
		if(is.null(names(criteria)[i])){idx <- i}else{idx <- names(criteria)[i]}

		if(idx == "EVAL"){

			# REPLACE COMPARISON SYMBOLS WITH STANDARD
			criteria[[idx]] <- gsub('=+', '=', criteria[[idx]])

			# SPLIT CRITERIA STRING
			split <- splitAt.TQ('(ONLY)? *(=|==|>=|>|<=|<|!=|!==)', criteria[[idx]], ignore.case=TRUE)
		
			if(is.null(split$split)) 
				stop(paste0("The conditional expression '", criteria[[idx]], "' lacks a symbol for comparison (e.g. >, <, =)."))

			split_text2 <- gsub("[[:space:]]*$|^[[:space:]]*", "", split$text[2])
			is_value_numeric <- grepl('^[0-9., ]+$', split_text2)
			if(is_value_numeric) split_text2 <- as.numeric(split$text[2])

			criteria[[idx]] <- list(
				"field" = tolower(gsub("[[:space:]]*$|^[[:space:]]*", "", split$text[1])), 
				"compare" = toupper(gsub("[[:space:]]*$|^[[:space:]]*", "", split$split)), 
				"value" = split_text2)
		}

		if(is.list(criteria[[idx]]) && idx != "EVAL"){
			criteria[[idx]] <- criteriaFormatEval(criteria[[idx]])
		}else{
			criteria[[idx]] <- criteria[[idx]]
		}
	}

	criteria
}