loadEvalRef <- function(dir, verbose=TRUE){
	
	if(!file.exists(dir)) stop(paste0("Input directory '", dir, "' not found."))

	list_files <- list.files(dir)

	if(length(list_files) == 0) stop(paste0("Input directory '", dir, "' is empty."))
	
	eval.ref <- NULL
	
	for(ref_type in list_files){

		eval.ref[[ref_type]] <- NULL

		type_dirs <- list.files(paste0(dir, "/", ref_type))
		
		if(length(type_dirs) == 0) next

		for(type_dir in type_dirs){

			type_files <- list.files(paste0(dir, "/", ref_type, "/", type_dir))

			if(length(type_files) == 0){
				message(paste0("Warning: No content found in directory '", dir, "/", ref_type, "/", type_dir, "'"))
				next
			}

			eval.ref[[ref_type]][[type_dir]] <- list()

			for(type_file in type_files){
				
				if(verbose) message(paste0("Loading file '", paste0(dir, '/', ref_type, '/', type_dir, '/', type_file), "'..."))

				first_line <- readLines(paste0(dir, '/', ref_type, '/', type_dir, '/', type_file), n=1)

				if(grepl('\t', first_line)){
					eval.ref[[ref_type]][[type_dir]][[gsub('.txt', '', type_file)]] <- 
						read.table(paste0(dir, '/', ref_type, '/', type_dir, '/', type_file), header=FALSE, sep="\t", quote="")
				}else{
					eval.ref[[ref_type]][[type_dir]][[gsub('.txt', '', type_file)]] <- 
						readLines(paste0(dir, '/', ref_type, '/', type_dir, '/', type_file))
				}
			}
		}
	}
	
	eval.ref
}