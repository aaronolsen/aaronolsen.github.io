readSets <- function(sets, entries){

	# CONVERT TO NUMERIC SET LIST IF NOT ALREADY
	if(!is.null(names(sets))) sets <- list(sets)

	return.list <- setNames(vector("list", length(entries)), entries)

	for(i in 1:length(sets)){
	
		set <- sets[[i]]
		for(entry in entries){
			
			sublist_names <- names(set)[!sapply(sapply(set, names), is.null)]

			if(is.null(set[[entry]])){
				
				for(sublist_name in sublist_names){
					if(is.null(set[[sublist_name]][[entry]])) next

					return.list[[entry]][[i]] <- set[[sublist_name]][[entry]]
				}
				
				if(i > length(return.list[[entry]])) return.list[[entry]][[i]] <- NA
				next
			}

			return.list[[entry]][[i]] <- set[[entry]]
		}
	}

	if(length(entries) == 1){
		if(is.vector(return.list[[entries[1]]])) return(return.list[[entries[1]]])
	}

	#all_vectors <- TRUE
	#for(entry in entries) if(is.list(return.list[[entry]])) all_vectors <- FALSE
	#if(all_vectors) return(sapply(return.list, '['))

	return.list
}