print.query_set <- function(x, ...){

	# CONVERT TO NUMERIC SET LIST IF NOT ALREADY
	if(!is.null(names(x))) x <- list(x)

	i <- 1
	
	for(i in 1:length(x)){
		cat("\nSet ", i, ":\n", sep="")
		
		set <- x[[i]]

		for(j in 1:length(set)){
			
			if(is.list(set[[names(set)[j]]])){

				# GET NUMBER OF SUBSET ELEMENTS
				subset_lengths <- unique(sapply(set[[names(set)[j]]], length))
			
				if(length(subset_lengths) > 1)
					stop(paste0("The elements of set group '", names(set)[j], "' are not of uniform size."))

				cat("\t", names(set)[j], sep="")
				
				if(length(names(set[[names(set)[j]]])) == 1){
					subset_mat <- setNames(unlist(set[[names(set)[j]]]), NULL)
					cat(" (", names(set[[names(set)[j]]]), "): ", sep="")
					cat(paste0(subset_mat, collapse=", "))
					cat("\n")
				}else{
					cat(":\n")
					subset_mat <- matrix(unlist(set[[names(set)[j]]]), 
						ncol=subset_lengths, byrow=TRUE, dimnames=list(names(set[[names(set)[j]]]), NULL))
					print(subset_mat)
				}
			}else{
				cat("\t", names(set)[j], ": ", sep="")
				if(length(set[[names(set)[j]]]) == 1){
					cat(set[[names(set)[j]]])
				}else{
					cat(paste0(set[[names(set)[j]]], collapse=", "))
				}
				cat("\n")
			}
		}
	}
	cat("\n")
}