criteriaAddChildren <- function(split, type, id, cond_type, children, parent = NULL){

	# FIND ROOT
	if(is.null(parent)) parent <- (1:length(split))[!1:length(split) %in% unlist(children)][1]

	join_id <- rep(NA, 0)

	r <- list()
	for(i in 1:length(children[[id[parent]]])){

		if(type[children[[id[parent]]][i]] == 'EVAL') 
			add <- list("EVAL" = split[children[[id[parent]]][i]])
			
		if(type[children[[id[parent]]][i]] == 'JOIN'){

			if(id[children[[id[parent]]][i]] %in% join_id) next
			
			add <- criteriaAddChildren(split, type, id, cond_type, children, children[[id[parent]]][i])
			join_id <- c(join_id, id[children[[id[parent]]][i]])
		}
		
		r[[cond_type[id[parent]]]][[length(r[[cond_type[id[parent]]]])+1]] <- add
	}

	r
}