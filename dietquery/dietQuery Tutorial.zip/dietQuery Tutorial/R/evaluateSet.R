evaluateSet <- function(set, criteria, eval.function, all.fields, col.index, eval.ref){

	# IF FIELD NAME IS NOT IN ENTIRE SET, RETURN NA
	if(!criteria$field %in% all.fields) return(NA)

	# IF FIELD NAME IS IN ENTIRE SET BUT NOT IN SUBSET, RETURN TRUE
	if(criteria$field %in% all.fields && !criteria$field %in% names(set)) return(TRUE)

	if(grepl("ONLY ", criteria$compare)){

		# REMOVE ONLY, LEAVING SIMPLE COMPARE SYMBOL
		criteria$compare <- gsub("ONLY ", "", criteria$compare)

		# EVALUATE FOR ALL ENTRIES IN FIELD
		for(i in 1:length(set[[criteria$field]])){

			evaluate_set <- evaluateSet(set, criteria, eval.function, all.fields, i, eval.ref)

			# RETURN NA IF ANY NA
			if(is.na(evaluate_set)) return(NA)
			
			# RETURN FALSE IF ANY FALSE
			if(evaluate_set == FALSE) return(FALSE)			
		}
		
		return(TRUE)
	}

	if(!is.null(eval.function)){
		return(do.call(eval.function, list(set, criteria, col.index, eval.ref)))
	}else{

		# IF VALUE IS NA, RETURN NA
		if(is.na(set[[criteria$field]][col.index])){
			if(criteria$value == "NA"){
				if(criteria$compare == "=") return(TRUE)
				if(criteria$compare == "!=") return(FALSE)
			}
			return(NA)
		}

		if(criteria$compare == "=")
			if(set[[criteria$field]][col.index] == criteria$value){return(TRUE)}else{return(FALSE)}

		if(criteria$compare == "!=")
			if(set[[criteria$field]][col.index] == criteria$value){return(FALSE)}else{return(TRUE)}

		if(criteria$compare == ">")
			if(set[[criteria$field]][col.index] > criteria$value){return(TRUE)}else{return(FALSE)}

		if(criteria$compare == "<")
			if(set[[criteria$field]][col.index] < criteria$value){return(TRUE)}else{return(FALSE)}

		if(criteria$compare == ">=")
			if(set[[criteria$field]][col.index] >= criteria$value){return(TRUE)}else{return(FALSE)}

		if(criteria$compare == "<=")
			if(set[[criteria$field]][col.index] <= criteria$value){return(TRUE)}else{return(FALSE)}
	}

	return(NA)
}