parseCriteria <- function(criteria){

	# REPLACE JOIN EXPRESSIONS WITH NON-ALPHANUMERIC
	criteria <- gsub(' OR ', ' || ', criteria, ignore.case=TRUE)
	criteria <- gsub(' AND ', ' && ', criteria, ignore.case=TRUE)

	# REMOVE DOUBLE SPACES
	criteria <- gsub(' +', ' ', criteria)

	# REMOVE PARENTHESES AROUND SINGLE CONDITIONAL EXPRESSIONS
	criteria <- gsub('[(]([[:alnum:]_ .,-]+)(=|==|>=|>|<=|<|!=|!==)([[:alnum:]_ .,-]+)[)]', '\\1\\2\\3', criteria)	

	# REPLACE PARENTHESES AROUND NON CONDITIONAL EXPRESSIONS WITH DOUBLE BRACKETS
	criteria <- gsub('[(]([[:alnum:]_ .,=!><-]+)[)]', '{{\\1}}', criteria)

	# REPLACE JOIN EXPRESSIONS WITH SINGLE STANDARD
	criteria <- gsub('[|]{1,2}', 'OR', criteria, ignore.case=TRUE)
	criteria <- gsub('[&]{1,2}', 'AND', criteria, ignore.case=TRUE)

	# DETERMINE IF FIRST AND LAST PARENTHESES ARE OF THE SAME EXPRESSION
	open <- rep(NA, 0)
	open_id <- 1
	for(i in 1:(nchar(criteria)-1)){
		if(substr(criteria, i, i) == '('){open <- c(open, open_id);open_id <- open_id + 1}
		if(substr(criteria, i, i) == ')') open <- open[1:(length(open)-1)]
	}

	# ADD PARENTHESES TO ENDS
	if(open[length(open)] != 1 || substr(criteria, nchar(criteria), nchar(criteria)) != ')') criteria <- paste0("(", criteria, ")")	

	# SPLIT AT JOIN
	split <- splitAt.TQ('AND|OR', criteria, intercalate=TRUE, trim=TRUE)
	
	if(length(split) > 1){

		# SET TYPES
		type <- rep(NA, length(split))
		type[seq(1, length(split), 2)] <- 'EVAL'
		type[seq(2, length(split), 2)] <- 'JOIN'

		# FIND NUMBER OF OPEN PARENTHESES
		num_id <- length(unlist(gregexpr('(', criteria, fixed=TRUE)))

		# CREATE EMPTY STRUCTURES
		children <- list();for(i in 1:num_id) children[[i]] <- rep(NA, 0)
		id <- rep(NA, length(split))
		level <- rep(NA, length(split))
		open <- rep(NA, 0)

		open_id <- 1
		open_level <- 1

		# ASSIGN IDS, CHILDREN AND LEVELS TO EACH ELEMENT
		for(i in 1:length(split)){
			for(j in 1:nchar(split[i])){

				# KEEP VECTOR OF IDS OF OPEN PARENTHESES
				if(substr(split[i], j, j) == '('){
					open <- c(open, open_id)
					open_level <- c(open_level, length(open_level) + 1)
					open_id <- open_id + 1
				}
			}

			id[i] <- open[length(open)]

			if(type[i] == 'JOIN') level[i] <- open_level[length(open_level)]
			if(type[i] == 'EVAL') children[[open[length(open)]]] <- c(children[[open[length(open)]]], i)
			if(type[i] == 'JOIN' && length(open)-1 > 0) 
				children[[open[length(open)-1]]] <- c(children[[open[length(open)-1]]], i)

			# ONCE PARENTHESIS CLOSES, REMOVE PARENTHESIS ID
			for(j in 1:nchar(split[i])){
				if(substr(split[i], j, j) == ')'){
					open <- open[1:(length(open)-1)]
					open_level <- open_level[1:(length(open_level)-1)]
				}
			}
		}

		# SET EMPTY CONDITIONAL TYPE VECTOR
		cond_type <- rep(NA, num_id)
	
		# MAKE SURE THAT JOINS AT THE SAME LEVEL AND WITH THE SAME ID HAVE THE SAME VALUE
		for(i in 1:num_id){
	
			# GET INDICES OF ALL JOIN ELEMENTS WITH THE SAME ID
			join_same_id <- (id == i) * (type == 'JOIN') == 1
		
			# MAKE SURE ALL JOIN ELEMENTS WITH THE SAME ID ARE AT THE SAME LEVEL
			if(length(unique(level[join_same_id])) > 1)
				stop("Syntax error. Not all elements in the same conditional expression are at the same hierarchical level.")

			# MAKE SURE ALL JOIN ELEMENTS WITH THE SAME ID ARE IDENTICAL
			if(length(unique(split[join_same_id])) > 1)
				stop(paste0("Syntax error. '", paste(unique(split[join_same_id]), collapse=", "), "' used in the same expression. Only one conditional type allowed per conditional expression."))

			# SET CONDITIONAL TYPE
			cond_type[i] <- split[join_same_id][1]
		}
	}

	# REMOVE PARENTHESES
	split <- gsub('[(]|[)]', '', split)

	# REPLACE DOUBLE BRACKETS WITH PARENTHESES
	split <- gsub('{{', '(', split, fixed=TRUE)
	split <- gsub('}}', ')', split, fixed=TRUE)

	if(length(split) > 1){
		# CREATE QUERY TREE
		criteria_tree <- criteriaAddChildren(split, type, id, cond_type, children)
		class(criteria_tree) <- 'criteria_tree'
	}else{

		# IF NO JOINS PRESENT (SINGLE CONDITIONAL EXPRESSION) TREAT AS ONE OR
		criteria_tree <- list("OR" = list(list("EVAL" = split)))
		class(criteria_tree) <- 'criteria_tree'
	}

	# FORMAT THE EVALUATION EXPRESSIONS
	criteria_tree <- criteriaFormatEval(criteria_tree)

	criteria_tree
}