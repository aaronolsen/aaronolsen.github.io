queryIsMember <- function(entry, group, ref.type, eval.ref, max=50){

	# RETURN TRUE IF BOTH ARE THE SAME
	if(entry == group) return(TRUE)

	# CHECK THAT REFERENCE EXISTS IN EVAL.REF
	if(is.null(eval.ref[[ref.type]])) stop(paste0("Reference type '", ref.type, "' not found or empty in eval.ref."))
	
	# SET DEFAULT RETURN
	return_value <- NA
	return_message <- NULL

	for(ref_name in names(eval.ref[[ref.type]])){
	
		names <- eval.ref[[ref.type]][[ref_name]][['names']]
		nodes <- eval.ref[[ref.type]][[ref_name]][['nodes']]

		if(!is.null(nodes)){

			#cat("\tIs '", entry, "' a member of '", group, "'?\n", sep="")

			# FIND ID OF ENTRY
			entry_row <- match(entry, names[, 1])
		
			# RETURN NA AND WARNING IF NOT FOUND
			if(is.na(entry_row)){return_message <- paste0("Warning: '", entry, "' was not found in the '", ref_name, "' names reference.");return_value <- NA;next}

			# FIND ID OF GROUP
			group_row <- match(group, names[, 1])
		
			# RETURN NA AND WARNING IF NOT FOUND
			if(is.na(group_row)){return_message <- paste0("Warning: '", group, "' was not found in the '", ref_name, "' names reference.");return_value <- NA;next}

			# IF BOTH HAVE THE SAME NODE NUMBER (ARE SYNONYMS) RETURN TRUE
			if(names[group_row, 2] == names[entry_row, 2]) return(TRUE)

			# GET GROUP NODE
			group_node <- names[group_row, 2]

			# SET INITIAL CHILD NODE FOR SEARCH
			child_node <- names[entry_row, 2]
			
			# IF ENTRY AND GROUP ARE BOTH FOUND, RETURN FALSE UNLESS A CHILD NODE IS NOT FOUND IN TRACING
			return_value <- FALSE

			# TRACE NODES THROUGH TO PARENT
			for(i in 1:max){

				# FIND ROW IN NODES WITH FIRST COLUMN AS CHILD NODE
				child_row <- match(child_node, nodes[, 1])

				# RETURN NA AND WARNING IF NOT FOUND
				if(is.na(child_row)){return_message <- paste0("Warning: Node '", child_node, " was not found in the '", ref_name, "' nodes reference.");return_value <- NA;break}
			
				# GET CHILD NODE FOR NEXT SEARCH (PARENT NODE)
				child_node <- nodes[child_row, 2]

				# IF PARENT NODE MATCHES GROUP NODE, RETURN TRUE
				if(child_node == group_node){
					return(TRUE)
				}

				# IF PARENT NODE REACHES 1 (ROOT), BREAK
				if(child_node == 1) break
			}

			if(is.na(return_value)) message(return_message)

			return(return_value)

		}else{

			# SET INITIAL VARIABLES
			group_names <- rep(NA, max)
			previous_level <- 1

			# CHECK IF ENTRY MATCHES FIRST NAME, IF MATCH FAILS NEED TO KNOW IF ENTRY WAS FOUND IN SET
			if(grepl(gsub('\t|\n', '', names[1]), entry)) return_value <- FALSE

			if(length(names) == 1) next

			for(i in 2:length(names)){

				# 1ST LEVEL BY DEFAULT
				level <- 1

				# COUNT THE NUMBER OF INITIAL TABS
				gregexpr_res <- gregexpr('\t', names[i])[[1]]

				# IF TABS PRESENT, GET LEVEL (ADD 1)
				if(!-1 %in% gregexpr_res) level <- length(gregexpr_res) + 1
		
				# CHANGE THE CURRENT GROUP NAME(S) IF LEVEL HAS CHANGED FROM PREVIOUS
				if(level > previous_level) group_names[level-1] <- gsub('\t|\n', '', names[i-1])
				if(level < previous_level) group_names[c(level:previous_level)] <- NA
			
				# DOES ENTRY MATCH LINE
				if(grepl(gsub('\t|\n', '', names[i]), entry)){

					#cat(level, "::", names[i], "::", paste0(group_names[!is.na(group_names)], collapse=", "), "\n")

					# IF ANY MATCH IS MADE, MAKE DEFAULT RETURN FALSE
					return_value <- FALSE
			
					# IF AT ZERO LEVEL, RETURN FALSE
					if(length(group_names[!is.na(group_names)]) == 0) break

					# IF MATCH IN GROUP NAMES, RETURN TRUE, IF NOT CONTINUE SEARCHING - MAY BE MEMBER OF MORE GROUPS
					if(TRUE %in% lapply(group_names[!is.na(group_names)], grepl, x=group)) return(TRUE)
				}

				previous_level <- level
			}

			# CHECK THAT GROUP NAME IS PRESENT IN REFERENCE
			names_search <- gsub('\t', '', names)
			
			# IF RETURN VALUE IS NA, ENTRY WAS NOT FOUND
			if(is.na(return_value)){return_message <- paste0("Warning: '", entry, "' was not found in the '", ref_name, "' names reference.");return_value <- NA;next}
			
			# SEARCH THROUGH NAMES AND IF GROUP IS FOUND, RETURN FALSE
			for(i in 1:length(names_search)) if(grepl(names_search[i], group)) {return(return_value);break}
			
			# OTHERWISE SET RETURN TO NA
			return_message <- paste0("Warning: '", group, "' was not found in the '", ref_name, "' names reference.")
			return_value <- NA
		}
	}

	if(is.na(return_value)) message(return_message)

	return(return_value)
}