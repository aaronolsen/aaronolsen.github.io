querySets <- function(sets, test.criteria, eval.function = NULL, eval.ref = NULL, include.criteria = NULL, return.as.set = FALSE, print.progress=FALSE){

	# PARSE CRITERIA, IF NOT YET PARSED
	if(class(test.criteria) == "character") test.criteria <- parseCriteria(test.criteria)

	# CONVERT TO NUMERIC SET LIST IF NOT ALREADY
	if(!is.null(names(sets))) sets <- list(sets)
	
	set.evaluate <- vector("list", length(sets))
	set.return <- list()

	if(print.progress) cat('Querying set #: ')

	for(i in 1:length(sets)){

		# GET SET
		set <- sets[[i]]
		
		if(print.progress) cat(i, ' ', sep='')

		# GET LIST NAMES
		names_is_null <- sapply(sapply(set, names), is.null)
		primary_names <- names(set)[names_is_null]
		sublist_names <- names(set)[!names_is_null]
		secondary_names <- unlist(sapply(set, names), use.names=FALSE)
		
		# MAKE EVALUATE LIST
		evaluate <- setNames(vector("list", length(primary_names)+length(secondary_names)), c(primary_names, secondary_names))

		# GET LIST WITH ONLY PRIMARY NAMES
		primary_set <- list();for(name in primary_names) primary_set[[name]] <- set[[name]]

		# APPLY CRITERIA TO PRIMARY SET
		#cat('Apply Criteria - Primary Set\n')
		apply_criteria <- applyCriteria(primary_set, test.criteria, NULL, eval.function, c(primary_names, secondary_names), 1, eval.ref)

		# EVALUATE CRITERIA FROM PRIMARY SET
		evaluate_criteria <- evaluateCriteria(apply_criteria)

		# SET EVALUATE AND ADVANCE TO NEXT SET AT FALSE OR NA, IF NOT RETURNING ENTIRE EVALUATED SET
		if(is.null(set.evaluate[[i]])){
			if(is.na(evaluate_criteria)){
				set.evaluate[[i]] <- NA
				if(!return.as.set) next
			}
			if(!is.na(evaluate_criteria) && evaluate_criteria == FALSE){
				set.evaluate[[i]] <- FALSE
				if(!return.as.set) next
			}
		}

		# SET EVALUATE RESULT TO ALL MEMBERS OF SET LIST
		evaluate[primary_names] <- evaluate_criteria
		
		# APPLY CRITERIA TO EACH SECONDARY SET
		#cat('Apply Criteria - Secondary Set\n')
		for(j in 1:length(sublist_names)){

			# GET NUMBER OF SUBSET ELEMENTS
			subset_lengths <- unique(sapply(set[[sublist_names[j]]], length))
			
			if(length(subset_lengths) > 1)
				stop(paste0("The elements of set group '", sublist_names[j], "' are not of uniform size."))

			#cat('\t', sublist_names[j], '\n', sep='')
			
			for(name in names(set[[sublist_names[j]]])) evaluate[[name]] <- rep(NA, subset_lengths)
			
			for(k in 1:subset_lengths){
				#print(k)

				# APPLY CRITERIA TO SECONDARY SET
				apply_criteria <- applyCriteria(set[[sublist_names[j]]], test.criteria, NULL, eval.function, 
					c(primary_names, secondary_names), col.index=k, eval.ref=eval.ref)
				#print(apply_criteria)

				# EVALUATE CRITERIA FROM EACH SECONDARY SET
				evaluate_criteria <- evaluateCriteria(apply_criteria)

				# SET EVALUATE RESULT TO ALL MEMBERS OF SECONDARY SET LIST
				for(name in names(set[[sublist_names[j]]])) evaluate[[name]][k] <- evaluate_criteria

				# SKIP IF EVALUATE IS NA
				if(is.na(evaluate_criteria)) next
				
				# ADD BREAK AT TRUE IF NOT RETURNING PROPORTION TRUE FOR FIELD IN SECONDARY SET
				if(!return.as.set && evaluate_criteria == TRUE) break
			}
			
			# GET RESULT FOR SUBLIST
			eval_sub <- evaluate[[names(set[[sublist_names[j]]])[1]]]

			# BREAK AT FALSE OR NA
			if(is.null(set.evaluate[[i]])){
				if(sum(is.na(eval_sub)) == length(eval_sub)){
					set.evaluate[[i]] <- NA
					if(!return.as.set) break
				}
				if(sum(na.omit(eval_sub)) == 0){
					set.evaluate[[i]] <- FALSE
					if(!return.as.set) break
				}
			}
		}
		#cat(i, '\n')

		# IF NOT FALSE OR NA, SET AS TRUE
		if(is.null(set.evaluate[[i]])) set.evaluate[[i]] <- TRUE
		
		set.return[[i]] <- evaluate
		set.return[[i]]$evaluate <- set.evaluate[[i]]
	}

	if(print.progress) cat('\n')

	if(!return.as.set) return(unlist(set.evaluate))

	class(set.return) <- 'query_set'

	set.return
}