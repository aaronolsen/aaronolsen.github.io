splitAt.TQ <- function(pattern, text, intercalate = FALSE, trim = FALSE, ...){

	# FIND SPLIT PATTERN
	regx_res <- gregexpr(pattern, text, ...)
	
	# IF SPLIT TEXT IS NOT FOUND, ONLY RETURN TEXT AND NULL FOR SPLIT
	if(length(regx_res[[1]]) == 1 && regx_res[[1]] == -1) return(list(text=text))
	
	# ADD ENDS TO SEARCH VECTORS FOR 
	char_len <- c(0, attr(regx_res[[1]], "match.length"))
	split_at <- c(1, regx_res[[1]], nchar(text)+1)

	if(intercalate){

		# SET EMPTY VECTOR
		text_vec <- rep(NA, 2*length(char_len) - 1)

		# FILL VECTOR WITH IN-BETWEEN VALUES
		j <- 1
		for(i in seq(1, length(text_vec), by=2))
			{text_vec[i] <- substr(text, split_at[j] + char_len[j], split_at[j+1] - 1);j <- j + 1}

		# FILL VECTOR WITH SPLIT VALUES
		j <- 1
		for(i in seq(2, length(text_vec), by=2))
			{text_vec[i] <- substr(text, split_at[j+1], split_at[j+1] + char_len[j+1] - 1);j <- j + 1}

		# TRIM WHITE SPACES AT ENDS IF SPECIFIED
		if(trim) text_vec <- gsub(" *$|^ *", "", text_vec)

		return(text_vec)
	}

	# SET UP EMTPY VECTORS
	text_vec <- rep(NA, length(char_len))
	split_id <- rep(NA, length(char_len)-1)

	# SAVE VALUES TO VECTORS
	for(i in 1:length(char_len)) text_vec[i] <- substr(text, split_at[i] + char_len[i], split_at[i+1] - 1)
	for(i in 1:(length(char_len)-1)) split_id[i] <- substr(text, split_at[i+1], split_at[i+1] + char_len[i+1] - 1)

	# TRIM WHITE SPACES AT ENDS IF SPECIFIED
	if(trim) text_vec <- gsub(" *$|^ *", "", text_vec)
	if(trim) split_id <- gsub(" *$|^ *", "", split_id)

	list(text=text_vec, split=split_id)
}
