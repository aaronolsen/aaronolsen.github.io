printCriteriaTree <- function(x, r, t, vbar=NULL, tab=NULL){
	
	if(is.null(names(x))){
		for(i in 1:length(x)){
			if(i == length(x)){
				r <- printCriteriaTree(x[[i]], r, t, vbar[vbar != t], tab=tab)
			}else{
				r <- printCriteriaTree(x[[i]], r, t, vbar, tab=tab)
			}
		}
	}else{

		if(length(x) == 1 && names(x)[1] == 'EVAL'){
			for(i in 1:t) if(i %in% vbar || t == i){r <- c(r, rep(' ', tab), '|', sep='')}else{r <- c(r, rep(' ', tab+1))}
			r <- c(r, '---- ')
			if(is.list(x[['EVAL']])){
				r <- c(r, "'", x[['EVAL']][['field']], "'")
				r <- c(r, " ", x[['EVAL']][['compare']], " ")
				if(is.numeric(x[['EVAL']][['value']])){
					r <- c(r, x[['EVAL']][['value']])
				}else{
					r <- c(r, "'", x[['EVAL']][['value']], "'")
				}
			}else{
				r <- c(r, x[['EVAL']])
			}
			r <- c(r, '\n')
			return(r)
		}

		for(j in 1:length(x)){
			for(i in 1:t) if(i %in% vbar || t == i){r <- c(r, rep(' ', tab), '|')}else{r <- c(r, rep(' ', tab+1))}

			r <- c(r, '---- ', names(x)[j], '\n')
			r <- printCriteriaTree(x[[names(x)[j]]], r, t+1, c(vbar, t+1), tab=tab)
			for(i in 1:t) if(i %in% vbar){r <- c(r, rep(' ', tab), '|')}else{r <- c(r, rep(' ', tab+1))}
			r <- c(r, '\n')
		}
	}
	
	r
}

print.criteria_tree <- function(x, ...){

	cat("\nCriteria tree:\n")
	
	# START PRINT CRITERIA TREE CALL
	r <- ''
	r <- printCriteriaTree(x, r, 1, tab=5)
	r <- paste0(r, collapse='')

	# REMOVE ENDING NEW LINES
	for(i in 1:10) r <- gsub('[ ]*\n$', '', r)

	cat(r, '\n\n', sep='')
}