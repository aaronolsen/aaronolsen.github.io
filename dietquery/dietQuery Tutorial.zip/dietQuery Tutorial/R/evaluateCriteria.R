evaluateCriteria <- function(criteria){

	r_list <- rep(FALSE, length(criteria[[names(criteria)[1]]]))
	for(i in 1:length(criteria[[names(criteria)[1]]])){
		if(names(criteria[[names(criteria)[1]]][[i]])[1] == 'EVAL'){
			r_list[i] <- criteria[[names(criteria)[1]]][[i]]$EVAL
		}else{
			r_list[i] <- evaluateCriteria(criteria[[names(criteria)[1]]][[i]])
		}
	}
	
	# ALL NA
	if(length(na.omit(r_list)) == 0) return(NA)

	if(names(criteria)[1] == "AND"){

		# ANY NA
		if(sum(is.na(r_list)) > 0) return(NA)

		# ALL TRUE
		if(sum(na.omit(r_list)) == length(na.omit(r_list))) return(TRUE)

		return(FALSE)
	}
	if(names(criteria)[1] == "OR"){

		# AT LEAST ONE TRUE
		if(length(na.omit(r_list[r_list == TRUE])) > 0) return(TRUE)

		# ALL NA
		if(sum(is.na(r_list)) == length(r_list)) return(NA)

		# ALL EITHER FALSE OR NA
		#if(length(na.omit(r_list[r_list == FALSE])) + sum(is.na(r_list)) == length(r_list)) return(NA)

		return(FALSE)
	}	

	return(NA)
}