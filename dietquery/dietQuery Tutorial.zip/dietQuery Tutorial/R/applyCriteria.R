applyCriteria <- function(set, criteria, parent.idx, eval.function, all.fields, col.index = 1, eval.ref = NULL){

	for(i in 1:length(criteria)){
		
		if(is.null(names(criteria)[i])){idx <- i}else{idx <- names(criteria)[i]}

		# IF PARENT CONDITIONAL IS OR, CHECK IF ANY EVALS ARE TRUE
		any_true <- FALSE
		if(!is.null(parent.idx) && parent.idx == "OR"){
			for(j in 1:length(criteria)){

				# IF A TRUE HAS BEEN FOUND WITHIN AN OR CONDITIONAL, SET ALL REST TO NA
				if(any_true){
					criteria[[j]] <- list("EVAL" = NA)
					next
				}

				# SKIP LIST ELEMENTS THAT DONT HAVE EVAL
				if(is.null(criteria[[j]][['EVAL']])) next

				# SKIP ELEMENTS THAT ARE STILL A LIST
				if(is.list(criteria[[j]][['EVAL']])) next

				# SKIP LIST ELEMENTS THAT DONT HAVE EVAL
				if(is.na(criteria[[j]][['EVAL']])) next

				# SET TO BREAK IF ANY OF THE EVALUATES HAVE BEEN TRUE
				if(criteria[[j]][["EVAL"]] == TRUE) any_true <- TRUE
			}
		}
		
		# BREAK AT TRUE, SINCE ONE TRUE IS SUFFICIENT FOR OR
		if(any_true) break

		if(idx == "EVAL")
			criteria[[idx]] <- evaluateSet(set, criteria[[idx]], eval.function, all.fields, col.index, eval.ref)

		if(is.list(criteria[[idx]]) && idx != "EVAL")
			criteria[[idx]] <- applyCriteria(set, criteria[[idx]], idx, eval.function, all.fields, col.index, eval.ref)
	}

	criteria
}