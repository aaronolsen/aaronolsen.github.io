library(StereoMorph)

print.scaling <- 10

c_params <- list(
	c(0.05, 6, 4),
	c(0.1, 6, 5),
	c(0.15, 7, 5),
	c(0.2, 7, 6),
	c(0.25, 8, 6),
	c(0.3, 8, 7),
	c(0.35, 9, 7),
	c(0.4, 9, 8),
	c(0.45, 10, 8)
)

for(i in 1:length(c_params)){

	inches <- c_params[[i]][1]
	nx <- c_params[[i]][2]
	ny <- c_params[[i]][3]
	square.size <- inches / ((1/72)*(print.scaling/100))

	file <- paste0('Checkerboard ', nx, 'x', ny, ', ', square.size, 
		'px (Print at ', print.scaling, ' percent scaling for ', inches, ' inch squares).jpg')

	drawCheckerboard(nx=nx, ny=ny, square.size=square.size, file)
}
