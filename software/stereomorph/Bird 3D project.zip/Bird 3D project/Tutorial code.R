# This file contains the R code to run examples in the 'Bird 3D Project' StereoMorph 
#	Tutorial using the R package StereoMorph. To run any of the following commands copy 
# 	and paste the function into the R console

## Getting started
	# Load the StereoMorph library
	library(StereoMorph)

	# Set 'Bird 3D Project' as your current working directory (replace with the file path on your computer)
	setwd('/Users/aaron/Documents/Bird 3D project')

## Creating a checkerboard
	# Set checkerboard filename
	file <- 'Checkerboard 8x6 (180px).jpg'

	# Create the checkerboard
	drawCheckerboard(nx=8, ny=6, square.size=180, file=file)


## Measuring checkerboard square size
	# Digitize image of checkerboard and ruler
	digitizeImages(image.file='Measure square size/Images', 
		shapes.file='Measure square size/Shapes')

	# Read square sizes from shape files for both checkerboards
	square_sizes <- readShapes('Measure square size/Shapes')$square.size


## Calibrating stereo cameras
	# Find calibration coefficients (DLT)
	cal_cam <- calibrateCameras(img.dir='Run 1/Calibrate/Images', 
		cal.file='Run 1/Calibrate/calibration.txt', corner.dir='Run 1/Calibrate/Corners', 
		sq.size='6.35 mm', nx=8, ny=6, verify.dir='Run 1/Calibrate/Images verify')

	# FLIPPED VIEW CASE ONLY (one camera view is upside down relative to the other)
	cal_cam <- calibrateCameras(img.dir='Run 1/Calibrate/Images',
		cal.file='Run 1/Calibrate/calibration.txt', corner.dir='Run 1/Calibrate/Corners',
		sq.size='6.35 mm', nx=8, ny=6, flip.view=TRUE, 
		verify.dir='Run 1/Calibrate/Images verify')

	# Read calibration coefficients from calibration file
	cal_coeff <- readXML4R('Run 1/Calibrate/calibration.txt')$calibration$cal.coeff


## Digitizing photographs
	# Open digitizing app with stereo image set
	digitizeImages(image.file='Run 1/Reconstruct/Images', shapes.file='Run 1/Reconstruct/Shapes 2D', 
		landmarks.ref = 'Shapes ref/landmarks_ref.txt', curves.ref = 'Shapes ref/curves_ref.txt',
		cal.file='Run 1/Calibrate/calibration.txt')


## 3D Reconstruction and unification
	# Run for all stereo image sets in Shapes 2D
	reconstructStereoSets(shapes.2d='Run 1/Reconstruct/Shapes 2D',
		shapes.3d='Run 1/Reconstruct/Shapes 3D', cal.file='Run 1/Calibrate/calibration.txt',
		even.spacing='Shapes ref/even_spacing.txt')

	# Run for single image pair per specimen
	reconstructStereoSets(shapes.2d='Run 1/Reconstruct/Shapes 2D (single aspect)',
		shapes.3d='Run 1/Reconstruct/Shapes 3D', cal.file='Run 1/Calibrate/calibration.txt',
		even.spacing='Shapes ref/even_spacing.txt')

	# Only run for particular file(s) using set.names
	reconstructStereoSets(shapes.2d='Run 1/Reconstruct/Shapes 2D',
		shapes.3d='Run 1/Reconstruct/Shapes 3D', cal.file='Run 1/Calibrate/calibration.txt',
		even.spacing='Shapes ref/even_spacing.txt', set.names=c('psittacus_erithacus_FMNH312899'))

	# Only run on modified files using update.only
	reconstructStereoSets(shapes.2d='Run 1/Reconstruct/Shapes 2D',
		shapes.3d='Run 1/Reconstruct/Shapes 3D', cal.file='Run 1/Calibrate/calibration.txt',
		even.spacing='Shapes ref/even_spacing.txt',	update.only=TRUE)

	# Reconstruct and set all curve points as landmarks (named by adding zeroes, 5 by default)
	# 	This will name curves by adding numbers at the end, preceeded by zeroes, 5 by default
	#	For example, points on the curve upper_bill_tomium_L would be:
	#	upper_bill_tomium_L_00001, upper_bill_tomium_L_00002, etc.
	reconstructStereoSets(shapes.2d='Run 1/Reconstruct/Shapes 2D',
		shapes.3d='Run 1/Reconstruct/Shapes 3D', cal.file='Run 1/Calibrate/calibration.txt',
		even.spacing='Shapes ref/even_spacing.txt', curve.name.width=5, curves.as.landmarks=TRUE)


## Reading and visualizing shape data
	# Set particular file to read
	file <- 'Run 1/Reconstruct/Shapes 3D/bubo_virginianus_FMNH488595.txt'
	
	# Read 3D shape data from particular file
	shapes <- readShapes(file=file)
	
	# Get 3D landmark coordinates (mm) for 'bubo_virginianus_FMNH488595'
	shapes$landmarks
	
	# Get a particular landmark from the matrix
	shapes$landmarks['cranium_occipital', ]
	
	# Get the names of the reconstructed curves
	names(shapes$curves)
	
	# Get 'upper_bill_tomium_L' curve points for 'bubo_virginianus_FMNH488595'
	shapes$curves$upper_bill_tomium_L

	# Set particular shape files to read
	files <- c(
		'bubo_virginianus_FMNH488595', 
		'psittacus_erithacus_FMNH312899_a1'
		)

	# Read 3D shape data from particular files
	shapes <- readShapes(file=paste0('Run 1/Reconstruct/Shapes 3D/', files, '.txt'))

	# Get a particular landmark from landmark array
	shapes$landmarks['cranium_occipital', , ]
	
	# Get all landmarks from a particular specimen
	shapes$landmarks[, , 'bubo_virginianus_FMNH488595']

	# Read all 3D shapes
	shapes <- readShapes('Run 1/Reconstruct/Shapes 3D')


## Visualizing shape data
	# Load the rgl package
	library(rgl)
	
	# Load shape data for bubo_virginianus_FMNH488595
	file <- 'Run 1/Reconstruct/Shapes 3D/bubo_virginianus_FMNH488595.txt'

	# Read shapes
	shapes <- readShapes(file=file)
	
	# Save the landmark matrix
	lm <- shapes$landmarks
	
	# Set ranges (to get correct aspect ratio)
	r <- apply(lm, 2, 'max') - apply(lm, 2, 'min')
	
	# Plot the landmarks
	plot3d(lm, aspect=c(r/r[3]), size=7)
	
	# Plot the curves
	lapply(shapes$curves, plot3d, size=4, col="lightblue", add=TRUE)


## Reflecting missing bilateral landmarks
	# Set specimen name
	specimens <- 'bubo_virginianus_FMNH488595'
	
	# Reflect missing bilateral shapes
	rms <- reflectMissingShapes(shapes=paste0('Run 1/Reconstruct/Shapes 3D/', specimens, '.txt'), 
		file=paste0('Run 1/Reconstruct/Shapes 3D reflected/', specimens, '.txt'), average=TRUE)

	# Get reflected landmarks
	rms$landmarks

	# Set multiple specimen names
	specimens <- c('bubo_virginianus_FMNH488595',
		 'psittacus_erithacus_FMNH312899_a1')

	# Reflect missing bilateral shapes
	reflectMissingShapes(shapes=paste0('Run 1/Reconstruct/Shapes 3D/', specimens, '.txt'), 
		file=paste0('Run 1/Reconstruct/Shapes 3D reflected/', specimens, '.txt'), average=TRUE)

	# Run reflectMissingShapes() over all files in Shapes 3D
	reflectMissingShapes(shapes='Run 1/Reconstruct/Shapes 3D', 
		file='Run 1/Reconstruct/Shapes 3D reflected', average=TRUE)

	# Reflect using shape structure input
	file <- 'Run 1/Reconstruct/Shapes 3D/bubo_virginianus_FMNH488595.txt'
	shapes <- readShapes(file=file)
	rms <- reflectMissingShapes(shapes=shapes, average=TRUE)

	# View reflection errors
	reflectMissingShapes(shapes=shapes, average=TRUE, print.progress=TRUE)

	# Create 3D rgl plot
	library(rgl)
	file <- 'Run 1/Reconstruct/Shapes 3D reflected/bubo_virginianus_FMNH488595.txt'
	shapes <- readShapes(file=file)
	lm <- shapes$landmarks
	r <- apply(lm, 2, 'max') - apply(lm, 2, 'min')
	plot3d(lm, aspect=c(r/r[3]), size=7)
	lapply(shapes$curves, plot3d, size=4, col="lightblue", add=TRUE)


## Aligning bilateral landmarks
	# Set specimen name
	specimens <- 'bubo_virginianus_FMNH488595'

	# Align bilateral shapes
	asm <- alignShapesToMidline(shapes=paste0('Run 1/Reconstruct/Shapes 3D reflected/', specimens, '.txt'), 
		file=paste0('Run 1/Reconstruct/Shapes 3D aligned/', specimens, '.txt'))

	# Get aligned landmarks
	asm$landmarks

	# Set multiple specimen names
	specimens <- c('bubo_virginianus_FMNH488595',
		 'psittacus_erithacus_FMNH312899_a1')

	# Reflect missing bilateral shapes
	alignShapesToMidline(shapes=paste0('Run 1/Reconstruct/Shapes 3D reflected/', specimens, '.txt'), 
		file=paste0('Run 1/Reconstruct/Shapes 3D aligned/', specimens, '.txt'))

	# Run alignShapesToMidline() over all files in Shapes 3D
	alignShapesToMidline(shapes='Run 1/Reconstruct/Shapes 3D reflected', 
		file='Run 1/Reconstruct/Shapes 3D aligned')

	# Align using shape structure input
	file <- 'Run 1/Reconstruct/Shapes 3D reflected/bubo_virginianus_FMNH488595.txt'
	shapes <- readShapes(file=file)
	asm <- alignShapesToMidline(shapes=shapes)

	# View alignment errors
	asm <- alignShapesToMidline(shapes=shapes, print.progress=TRUE)

	# Create 3D rgl plot
	library(rgl)
	file <- 'Run 1/Reconstruct/Shapes 3D aligned/bubo_virginianus_FMNH488595.txt'
	shapes <- readShapes(file=file)
	lm <- shapes$landmarks
	r <- apply(lm, 2, 'max') - apply(lm, 2, 'min')
	plot3d(lm, aspect=c(r/r[3]), size=7)
	lapply(shapes$curves, plot3d, size=4, col="lightblue", add=TRUE)


## Testing the accuracy using a second checkerboard
	# Test calibration
	test_cal <- testCalibration(img.dir='Run 1/Test calibration/Images', 
		cal.file='Run 1/Calibrate/calibration.txt', 
		corner.dir='Run 1/Test calibration/Corners', sq.size='5.080 mm', nx=7, ny=6,
		plot.dir='Run 1/Test calibration/Error tests', 
		verify.dir='Run 1/Test calibration/Images verify')
